package com.example.firebaseuser;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.github.mikephil.charting.charts.LineChart;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import org.checkerframework.checker.nullness.qual.NonNull;

import java.util.HashMap;
import java.util.Map;

public class UpdateData extends AppCompatActivity {

    TextView backButton;
    TextInputEditText input_temp,input_wind;
    Button update_data;
    FirebaseAuth auth;
    FirebaseUser user;
    FirebaseFirestore firestore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_data);

        backButton = findViewById(R.id.Back_btn);
        input_temp = findViewById(R.id.temp);
        input_wind = findViewById(R.id.wind);
        update_data = findViewById(R.id.send_to_firebase_btn);
        firestore = FirebaseFirestore.getInstance();
        auth = FirebaseAuth.getInstance();
        user = auth.getCurrentUser();

        DocumentReference docRef = firestore.collection("users").document(user.getUid());



        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
                finish();
            }
        });

        // update information
        update_data.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String temp = input_temp.getText().toString().trim();
                String wind = input_wind.getText().toString().trim();
                if (TextUtils.isEmpty(temp) || TextUtils.isEmpty(wind)) {
                    Toast.makeText(UpdateData.this, "Filed Should Not Be Empty", Toast.LENGTH_LONG).show();
                    return;
                }

                    Map<String, Object> data = new HashMap<>();
                    data.put("Temp", temp);
                    data.put("Wind", wind);

                        docRef.set(data)
                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                Toast.makeText(UpdateData.this, "Data updated successfully!", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                                startActivity(intent);
                                finish();
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(UpdateData.this, "Error updating data: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        });



            }
        });
    }
}
