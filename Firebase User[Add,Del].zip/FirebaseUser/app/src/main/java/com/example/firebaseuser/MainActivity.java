package com.example.firebaseuser;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;

import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import org.checkerframework.checker.nullness.qual.Nullable;

import java.util.ArrayList;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    TextView information;
    TextView username,show_temp,show_wind;
    FirebaseAuth auth;
    FirebaseUser user;

    LineChart lineChart;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        // when user press Logout Button
        int id = item.getItemId();
        if (id == R.id.logout_item) {
            FirebaseAuth.getInstance().signOut();
            Toast.makeText(this, "User Logout.!", Toast.LENGTH_LONG).show();
            FirebaseAuth.getInstance().signOut(); // set to Logout From Application
            Intent intent = new Intent(getApplicationContext(), Login.class);
            startActivity(intent);
            finish();
        }

    // things to do when user press upload custom data
        else if(id == R.id.upload_item)
        {

            Toast.makeText(this, "User Update Page.!", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(getApplicationContext(), UpdateData.class);
            startActivity(intent);
            finish();
        }

        if(id == R.id.add_device)
        {
            Intent intent = new Intent(getApplicationContext(), AddDevice.class);
            startActivity(intent);
            finish();

        }
        if(id == R.id.delete_device)
        {
            Intent intent = new Intent(getApplicationContext(), DeleteDevice.class);
            startActivity(intent);
            finish();

        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        auth = FirebaseAuth.getInstance();
        information = findViewById(R.id.user_info);
        username = findViewById(R.id.username);
        lineChart = findViewById(R.id.line_chart);

        //textviews for wind and temp
        show_wind = findViewById(R.id.show_wind);
        show_temp = findViewById(R.id.show_temp);

        //line graph code
        user = auth.getCurrentUser();
        if (user != null) {
            String email = user.getEmail();
            String userEmail = email.substring(0, email.indexOf("@"));

            username.setText("Username : " + userEmail);
            information.setText("UserID : " + user.getUid());

            FirebaseAuth auth = FirebaseAuth.getInstance();
            FirebaseFirestore db = FirebaseFirestore.getInstance();
            String userId = auth.getCurrentUser().getUid();

            db.collection("users").document(userId)
                    .addSnapshotListener(new EventListener<DocumentSnapshot>() {
                        @Override
                        public void onEvent(@Nullable DocumentSnapshot snapshot,
                                            @Nullable FirebaseFirestoreException error) {
                            if (error != null) {
                                // Handle error
                                return;
                            }

                            if (snapshot != null && snapshot.exists()) {
                                // Get the data from the snapshot
                                String t = snapshot.getString("Temp");
                                String w = snapshot.getString("Wind");

                                // Update UI or do something with the data
                                show_temp.setText("Temp: " + t);
                                show_wind.setText("Wind: " + w);
                            }
                        }
                    });


            //db.collection end
        } else {
            Intent intent = new Intent(getApplicationContext(), Login.class);
            startActivity(intent);
            finish();
        }


//        logout.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                FirebaseAuth.getInstance().signOut();
//                Toast.makeText(MainActivity.this, "User Logout.!", Toast.LENGTH_LONG).show();
//                Intent intent = new Intent(getApplicationContext(), Login.class);
//                startActivity(intent);
//                finish();
//            }
//        });
    }

    private List<Entry> dataValues() {
        ArrayList<Entry> dataValue = new ArrayList<>();
        dataValue.add(new Entry(2,10));
        dataValue.add(new Entry(1,15));
        dataValue.add(new Entry(5,25));
        dataValue.add(new Entry(3,30));
        dataValue.add(new Entry(6,20));
        return dataValue;
    }
}
