package com.example.firebaseuser;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;


public class AddDevice extends AppCompatActivity {

    Button back, add_device;
    EditText device_name, phone_number;

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(intent);
        finish();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_device);
        getSupportActionBar().setHomeButtonEnabled(true);

        device_name = findViewById(R.id.device_name_text);
        phone_number = findViewById(R.id.editTextPhone);

        add_device = findViewById(R.id.add_device_btn);
        add_device.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = device_name.getText().toString().trim();
                String number = phone_number.getText().toString().trim();

                if (name.isEmpty() || number.isEmpty()) {
                    Toast.makeText(AddDevice.this, "Fields Should Not Be Empty.!", Toast.LENGTH_LONG).show();
                } else {
                    try {
                        long mobile_number = Long.parseLong(number);
                        // perform Add-Device Action
                    } catch (NumberFormatException e) {
                        Toast.makeText(AddDevice.this, "Invalid Mobile Number.!", Toast.LENGTH_LONG).show();
                    }
                }
            }
        });

        back = findViewById(R.id.add_device_back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }
}
