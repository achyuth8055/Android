package com.example.add;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private CheckBox check1,check2,check3;
    private Button button_select;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        addListnerOnButton();
        addButtonListner();
    }

    private void addButtonListner() {
        check1 = (CheckBox) findViewById(R.id.checkbox_dog);
        check2 = (CheckBox) findViewById(R.id.checkbox_cat);

        check1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(((CheckBox)v).isChecked())
                Toast.makeText(MainActivity.this, "DOG Selected", Toast.LENGTH_LONG).show();
            }
        });



        check2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(check2.isChecked())
                {
                    Toast.makeText(MainActivity.this, "Cat Selected", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    public void addListnerOnButton()
    {
        check1 = (CheckBox) findViewById(R.id.checkbox_dog);
        check2 = (CheckBox) findViewById(R.id.checkbox_cat);
        check3 = (CheckBox) findViewById(R.id.checkbox_cow);
        button_select = (Button) findViewById(R.id.button);
        button_select.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                StringBuffer result = new StringBuffer();
                result.append("dog : ").append(check1.isChecked());
                result.append("\n cow : ").append(check3.isChecked());
                result.append("\n cat : ").append(check2.isChecked());

                Toast.makeText(MainActivity.this,result.toString(),Toast.LENGTH_LONG).show();
            }
        });
    }


}