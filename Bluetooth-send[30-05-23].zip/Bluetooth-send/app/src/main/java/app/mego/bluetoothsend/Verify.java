package app.mego.bluetoothsend;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

/**
 * Created by Achyuth on 5/28/2023.
 */



public class Verify extends AppCompatActivity {

    private ConnectedThread connectedThread;
    private Button verifyButton, showInputs;
    private EditText passwordText;
    boolean value;
    private boolean isInputsVisible = false;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verify);

        verifyButton = (Button)findViewById(R.id.buttonVerify);
        passwordText = (EditText) findViewById(R.id.verify_code);
        showInputs = (Button)findViewById(R.id.show);

        verifyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (VerifyMessage()) {
                    passwordText.setText("");
                    isInputsVisible = false;
                    updateVisibility();
                } else {
                    Toast.makeText(getApplicationContext(), "False", Toast.LENGTH_LONG).show();
                }
            }
        });

        showInputs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                isInputsVisible = !isInputsVisible;
                updateVisibility();
            }
        });
    }

    private void updateVisibility() {

        if (isInputsVisible) {
            verifyButton.setVisibility(View.VISIBLE);
            passwordText.setVisibility(View.VISIBLE);
            showInputs.setText("Hide Inputs");
        } else {
            verifyButton.setVisibility(View.INVISIBLE);
            passwordText.setVisibility(View.INVISIBLE);
            showInputs.setText("Show Inputs");
        }
    }

    public boolean VerifyMessage() {
        String password = passwordText.getText().toString();
        if (password.equals("1234")) {
            Toast.makeText(Verify.this, "True", Toast.LENGTH_LONG).show();
            value = true;
        } else {
            value = false;
        }
        return value;
    }
}
